# 高中英文作文精批與修訂 v4

跨 agent 批改規則 + 固定 PDF / Excel 輸出模板。Skill 呼叫名稱維持 `english-essay-feedback`。

## 分工

Agent 負責辨識、評分、批改與填寫 JSON；模板負責驗證資料、字數核算、排版及輸出。模板不自動評分、不替學生作答，也不保證不同模型評分完全相同。教師仍需覆核。

任何能讀取檔案、填寫 JSON 並執行 Python 的 agent 都可使用此流程。沒有程式執行能力的聊天工具可以填 JSON，但需交由其他執行環境製作成品。`agents/openai.yaml` 只是 OpenAI 顯示設定，不是渲染器依賴。

## 執行

1. 安裝 Python 3.10 以上與 `python -m pip install -r requirements.txt`。
2. 依 `templates/feedback.schema.json` 填寫資料；`examples/demo.json` 是完全虛構的可執行範例。
3. 提供合法可用的中文字型一般／粗體與英文手寫字型。字型不隨套件重散布。TTF 或受支援的 TTC 均可；不同機器使用相同字型可提高版面一致性。
4. 在套件目錄執行：

```text
python scripts/render_feedback.py examples/demo.json --out output/demo-v2 --font /path/to/cjk-regular.ttf --bold /path/to/cjk-bold.ttf --hand /path/to/handwriting.ttf
```

Windows 字型參數可使用 `C:/Windows/Fonts/msjh.ttc`、`C:/Windows/Fonts/msjhbd.ttc`、`C:/Windows/Fonts/comicbd.ttf`。macOS / Linux 請提供實際安裝的字型檔路徑。無效字型會停止，不能以缺字方框交付。

輸出目錄必須尚未存在，避免覆寫原稿或舊成品。輸出包括每生 `id_full.pdf`、`class_print.pdf`、`classroom.xlsx`、`audit.json`。每生前兩頁固定，後續詳解自動分頁。

## 原稿與紅筆位置

`scan` 為相對於 JSON 的原稿圖片路徑。未提供時，第一頁明確顯示逐字稿，不能假裝已在手寫原稿上批改。多頁原稿需先整理成可讀的版面；若第一頁容不下，先與教師調整列印安排，不縮小字硬塞。

`annotations` 各筆為 `x,y,width,label,text,operation,target`。座標從原稿圖片左上角起算，0–1 為相對比例，y 是批改文字框上緣。將註記放在原字上方留白；工具檢查註記彼此重疊與越界，仍須目視確認沒有蓋住原字。修訂字級固定 12pt。插入、替換、刪除的定位詳見下方v3說明。

## 固定版型與品質

第1頁原稿／紅筆、分項橫表、字數及2–5個「也可以這樣寫」細框，不重複短評。第2頁評分表與完整英中評語，以及「我修正了什麼／我強化了什麼／我下次會怎麼做」作答區，包含修訂、理由、內容強化、目標、自評、日期與教師核閱。第3頁起逐句精修及雙語範文。正文11–12pt，紅筆12pt，不縮字；版面超容量即報錯，須調整表述或安排。

Excel 使用隨附固定範本；執行時以 Python 標準 XML/ZIP API 填入資料，不依賴 Codex 私有函式庫。包含成績、評語、修訂、錯誤、反思、摘要六表；總分、字數差異及摘要有公式與初始快取，Excel 開啟後重算。修改 Excel 不會反向更新 PDF，請修改 JSON 後產生新版本以保持一致。

所有作文採最新學測四項各5分量尺，包含自編題與舊年度試題。欄位為內容、組織、文法句構、字彙拼字。姓名不確定填「待核對」；疑義列於 `uncertainties`。必填 `rubric_source`、大考中心 `rubric_url` 及 `rubric_checked`，每次批改先核實最新公告。

這是固定產出管線，不包含其他 agent 的帳號設定、GitHub 授權或自動同步。驗證一個 agent 可執行，不代表已在所有 agent / 作業系統實測。範例完全虛構；上傳 GitHub 不包含教師字型或學生資料。

## 2026-10-14 驗證紀錄

已在 Windows 執行短文、840字120句長文、多生排序與每人兩頁合併、缺中譯／分數越界／重複身份／逐字稿不一致等拒絕測試，以及合成原稿影像紅筆註記測試。Excel 六表已渲染檢視；試算表引擎修改內容分數3→4後，總分11→12，並確認同生兩筆 G 錯誤只計一位學生。未在 macOS、Linux 或其他 agent 實測，也未驗證原生 Excel 的全部操作。

`scripts/test_renderer.py` 內的整合測試使用 Windows 系統字型；在其他作業系統執行測試前需替換測試字型路徑。渲染器本身以命令列字型參數運作。

## v3 修改

資料版本改為3.0，舊2.0資料需遷移。第一頁取消短評；舊 `short_comment` 可選留在教師Excel，不再列印。可接受原用法保留，必要修正與可選升級分開。紅筆註記必填 `operation`（insert/replace/delete）及 `target`，以caret、刪除線、加粗定位線及黑白標籤呈現。

`target` 為 `[x, y, width]`，座標相對於原稿左上角，y為原字基線，插入width必須為0。一般字詞caret從基線下方朝上指向該點；上方標點插入目前須由agent另行處理。更自然的選項可放第一頁獨立細框，不作錯誤註記。

完成並驗證後同步通用skill到教師既有GitHub私有備份，保留舊版本；學生檔案與姓名成績不隨套件上傳。

## v4 修改與資料遷移

`schema_version` 改4.0，新增必填 `focus_original`（第一項任務的原句片段）及 `optional_rewrites`（可選潤飾資料）。每項包含 `sentence_id`、`original`、`alternative`、`note`。通常依需要2–5項，上限5；無合理建議時可留空，不硬湊。第一頁模板以兩欄、逐列等高的細框排版，版面不足會停止，不能壓縮原稿或減小字級。

可選資料中的 `original` 可以是原本可接受的片語，也可以是已完成必要文法修正後、仍保留學生用字的基礎版本；後者須在 `note` 寫「原用字可保留」，不能宣稱原始錯誤句本身正確。例如先修成 my thought has changed，再並陳 my preference has changed。

刪除操作只畫線，`text` 可留空，不顯示類別、編號、文字或引線。其他操作仍需文字。第二頁把三項任務整合於三個反思區；首項有原句、修訂與理由，第二區呈現另兩項任務，第三區留目標與自評。不要把同樣的修訂理由重問一次。

不再印出歷程證據清單、教師範文免責文字或要求另附完整修訂稿的指示。這是一張可直接完成並繳交的作文修訂反思紀錄；教師的證據保存與教學協助說明仍保留在教師端或詳解頁。
