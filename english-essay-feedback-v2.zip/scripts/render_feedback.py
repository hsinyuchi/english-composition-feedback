"""Render validated, agent-neutral JSON using fixed PDF and XLSX templates."""
import argparse
from copy import deepcopy
from html import escape
import json
from pathlib import Path
import re
import shutil
import tempfile
import xml.etree.ElementTree as ET
from zipfile import ZipFile, ZIP_DEFLATED

from jsonschema import Draft202012Validator
from PIL import Image
from pypdf import PdfReader, PdfWriter
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.pdfgen import canvas
from reportlab.platypus import SimpleDocTemplate, Paragraph, Table, TableStyle, Spacer

from essay_tools import count_words

ROOT = Path(__file__).resolve().parents[1]
THEME = json.loads((ROOT / 'templates/theme.json').read_text(encoding='utf-8'))
W, H = A4
NS = 'http://schemas.openxmlformats.org/spreadsheetml/2006/main'
ET.register_namespace('', NS)


def validate(data, base):
    schema = json.loads((ROOT / 'templates/feedback.schema.json').read_text(encoding='utf-8'))
    Draft202012Validator(schema).validate(data)
    ids, seats = set(), set()
    for s in data['students']:
        key = (s['class'], s['seat'])
        if s['id'] in ids or key in seats:
            raise ValueError('Duplicate student ID or class/seat')
        ids.add(s['id']); seats.add(key)
        if any(x['value'] > x['max'] for x in s['scores']):
            raise ValueError('Score exceeds maximum')
        if s['deduction'] > sum(x['value'] for x in s['scores']):
            raise ValueError('Deduction exceeds earned score')
        sentence_ids = [x['id'] for x in s['sentences']]
        if sentence_ids != list(range(1, len(sentence_ids)+1)):
            raise ValueError('Sentence IDs must be consecutive from 1')
        normalize = lambda t: re.sub(r'\s+', ' ', t).strip()
        if normalize(' '.join(s['paragraphs'])) != normalize(' '.join(x['original'] for x in s['sentences'])):
            raise ValueError('Original sentences do not match transcription')
        if any(e['sentence_id'] not in sentence_ids for e in s['errors']):
            raise ValueError('Error references missing sentence')
        if s.get('scan') and not (base / s['scan']).is_file():
            raise ValueError('Missing scan image')
        if s.get('annotations') and not s.get('scan'):
            raise ValueError('Annotations require a scan image')
        for a in s.get('annotations', []):
            if a['x'] + a['width'] > 1:
                raise ValueError('Annotation extends beyond scan width')
    if len({tuple((x['label'], x['max']) for x in s['scores']) for s in data['students']}) != 1:
        raise ValueError('A batch must use one consistent rubric')


def register_fonts(regular, bold, hand):
    for name, path in [('Body', regular), ('Bold', bold), ('Hand', hand)]:
        if not path or not Path(path).is_file():
            raise ValueError(f'Provide an existing font file for {name}')
        pdfmetrics.registerFont(TTFont(name, str(path)))


def para(text, size=11, font='Body', color=None):
    glyphs=pdfmetrics.getFont(font).face.charToGlyph
    missing={ch for ch in str(text) if not ch.isspace() and ord(ch) not in glyphs}
    if missing:raise ValueError(f'Font {font} is missing characters: {"".join(sorted(missing))}')
    return Paragraph(escape(str(text)).replace('\n', '<br/>'), ParagraphStyle(
        'p', fontName=font, fontSize=size, leading=size*1.38,
        textColor=colors.HexColor(color or THEME['ink']), wordWrap='CJK', spaceAfter=7, keepWithNext=size>=13))


def put(c, text, x, y, width, size=11, font='Body', color=None, floor=50):
    p = para(text, size, font, color)
    _, height = p.wrap(width, H)
    if y-height < floor:
        raise ValueError(f'Layout overflow; shorten content, never shrink text: {text[:60]}')
    p.drawOn(c, x, y-height)
    return y-height-7


def heading(c, text, x, y, width):
    return put(c, text, x, y, width, 13, 'Bold', THEME['accent'])


def frame(c, data, s, page):
    c.setFillColor(colors.HexColor(THEME['accent'])); c.rect(0,H-7,W,7,fill=1,stroke=0)
    c.setFont('Bold',9); c.drawString(36,H-26,'THE WRITING EDIT')
    c.setFillColor(colors.HexColor(THEME['muted'])); c.setFont('Body',9)
    c.drawRightString(W-36,H-26,f"{s['class']} / {s['seat']:02d} / {s['name']}")
    c.setStrokeColor(colors.HexColor('#BAC8C0')); c.line(36,35,W-36,35)
    c.drawString(36,21,'原稿 → 訂正 → 理解 → 自己修訂')
    c.drawRightString(W-36,21,str(page).zfill(2))


def table(c, rows, widths, x, y, floor=50):
    content = [[para(v,11,'Bold' if i==0 else 'Body','#FFFFFF' if i==0 else None) for v in row] for i,row in enumerate(rows)]
    t = Table(content, colWidths=widths)
    t.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),colors.HexColor(THEME['ink'])),
        ('VALIGN',(0,0),(-1,-1),'TOP'),('ROWBACKGROUNDS',(0,1),(-1,-1),[colors.white,colors.HexColor('#EEF4F0')]),
        ('BOTTOMPADDING',(0,0),(-1,-1),6),('TOPPADDING',(0,0),(-1,-1),6)]))
    _, height = t.wrap(sum(widths),H)
    if y-height < floor: raise ValueError('Table overflow')
    t.drawOn(c,x,y-height)
    return y-height-10


def lines(c,x,y,width,n):
    c.setStrokeColor(colors.HexColor('#B8C4BD'))
    for _ in range(n):
        y -= 21
        if y < 64: raise ValueError('Insufficient writing space on page 2')
        c.line(x,y,x+width,y)
    return y-12


def total(s): return sum(x['value'] for x in s['scores'])-s['deduction']
def counts(s): return count_words('\n\n'.join(s['paragraphs']))


def front(path, data, s, base):
    c = canvas.Canvas(str(path),pagesize=A4)
    frame(c,data,s,1)
    y = put(c,data['assignment'],36,H-49,W-72,21,'Bold')
    y = put(c,f"原稿 {counts(s)['total']} 字 | 教學估分 {total(s):g} / {sum(x['max'] for x in s['scores']):g}",36,y,W-72,12,'Bold')
    top, bottom = y-4, 245
    if s.get('scan'):
        with Image.open(base / s['scan']) as image:
            image_width,image_height=image.size
        if image_height / image_width > 1.8:
            raise ValueError('Long scan: split into readable pages before annotation; do not shrink handwriting')
        scale = min((W-72)/image_width, (top-bottom)/image_height)
        iw,ih = image_width*scale,image_height*scale
        ix,iy = (W-iw)/2, top-ih
        c.drawImage(str(base/s['scan']),ix,iy,iw,ih)
        boxes = []
        for a in s.get('annotations',[]):
            ax, ay, aw = ix+a['x']*iw, top-a['y']*ih, a['width']*iw
            if aw < 42: raise ValueError('Annotation width too small')
            p = para(a['text'],THEME['annotation_size'],'Hand',THEME['red'])
            _,ph = p.wrap(aw-25,H)
            box = (ax,ay-ph,ax+aw,ay)
            if box[1] < iy: raise ValueError('Annotation below scan boundary')
            if any(box[0]<b[2] and box[2]>b[0] and box[1]<b[3] and box[3]>b[1] for b in boxes):
                raise ValueError('Annotations overlap; adjust normalized coordinates')
            boxes.append(box)
            c.setFillColor(colors.black);c.rect(ax,ay-13,21,13,fill=1,stroke=0)
            c.setFillColor(colors.white);c.setFont('Helvetica-Bold',9);c.drawString(ax+3,ay-10,a['label'])
            p.drawOn(c,ax+25,ay-ph)
    else:
        yy = heading(c,'原稿逐字稿（未提供手寫影像）',36,top,W-72)
        original='\n\n'.join(s['paragraphs'])
        preview=original
        while para(preview,12).wrap(W-72,H)[1] > yy-bottom-32:
            preview=preview[:-30]
            if not preview: raise ValueError('No room for original preview')
        if preview != original:
            preview += '\n（原稿節錄；完整原文見第3頁起。）'
        put(c,preview,36,yy,W-72,12,floor=bottom)
    y = table(c,[[x['label'] for x in s['scores']], [f"{x['value']:g} / {x['max']:g}" for x in s['scores']]],[(W-72)/4]*4,36,233)
    y = heading(c,'給你的短評',36,y,W-72)
    y = put(c,s['short_comment']['en'],36,y,W-72)
    put(c,s['short_comment']['zh'],36,y,W-72)
    c.showPage();frame(c,data,s,2)
    y = put(c,'讀懂分數，留下自己的進步',36,H-49,W-72,21,'Bold')
    ct = counts(s); reported = s['reported_count']
    y = put(c,f"核算 {ct['total']} 字（各段：{' + '.join(str(p['count']) for p in ct['paragraphs'])}） | 自填：{reported if reported is not None else '未填'}",36,y,W-72)
    y = put(c,'依原稿空白分詞，獨立標點不計，錯字仍計詞；辨識疑義見逐句頁。',36,y,W-72)
    col=(W-94)/2; right=58+col
    left_y=heading(c,'評分依據',36,y,col)
    left_y=table(c,[['項目','分數','給分理由']]+[[x['label'],f"{x['value']:g}/{x['max']:g}",x['reason']] for x in s['scores']],[68,35,col-103],36,left_y)
    left_y=put(c,f"額外扣分 {s['deduction']:g}：{s['deduction_reason']}",36,left_y,col)
    left_y=put(c,'依據：'+data['rubric_source'],36,left_y,col)
    left_y=heading(c,'完整英中評語',36,left_y,col)
    for lang in ['en','zh']:left_y=put(c,s['full_comment'][lang],36,left_y,col)
    left_y=heading(c,'我的學習反思',36,left_y,col)
    for i,question in enumerate(s['reflections'],1):
        left_y=put(c,f'{i}. {question}',36,left_y,col)
        left_y=lines(c,36,left_y,col,1 if i==1 else 2)
    ry=heading(c,'本篇專屬修訂任務',right,y,col)
    for i,task in enumerate(s['tasks'],1):
        ry=put(c,f"{i}. {task['instruction']}",right,ry,col)
        ry=lines(c,right,ry,col,task['lines'])
    put(c,'另附自己的完整修訂稿；教師範文供對照，不是學生學習成果。',right,ry,col)
    c.save()


def detail(path,data,s):
    story=[para('原稿完整逐字稿',16,'Bold',THEME['accent'])]+[para(x,12) for x in s['paragraphs']]+[Spacer(1,15)]
    if s['uncertainties']:
        story += [para('待核對事項',16,'Bold')]+[para(x) for x in s['uncertainties']]
    for sent in s['sentences']:
        story += [para(f"SENTENCE {sent['id']:02d}",16,'Bold',THEME['accent']),para('原句：'+sent['original']),para('基本修正：'+sent['basic'])]
        story += [para('說明：'+note) for note in sent['notes']]
        story += [para('進階表達：'+sent['advanced']),Spacer(1,15)]
    from reportlab.platypus import PageBreak
    for key,title in [('basic','基礎版'),('advanced','進階版')]:
        story += [PageBreak(),para(title+'完整文章｜英中對照',20,'Bold'),para('教師示範；進階版新增內容需與原稿區分。')]
        for i,pair in enumerate(s['models'][key],1):
            story += [para(f'第 {i} 段',13,'Bold',THEME['accent']),para(pair['en'],12),para(pair['zh'],12),Spacer(1,10)]
    doc=SimpleDocTemplate(str(path),pagesize=A4,leftMargin=36,rightMargin=36,topMargin=52,bottomMargin=50)
    doc.build(story,onFirstPage=lambda c,d:frame(c,data,s,d.page+2),onLaterPages=lambda c,d:frame(c,data,s,d.page+2))


def column(n):
    result=''
    while n:n,r=divmod(n-1,26);result=chr(65+r)+result
    return result


def workbook(data, path):
    """Populate an artifact-tool-authored workbook using portable OOXML APIs."""
    students=data['students']; n=len(students)
    rows=[[],[],[],[],[],[]]
    for i,s in enumerate(students,2):
        ct=counts(s)
        rows[0].append([s['id'],s['class'],s['seat'],s['name'],*[x['value'] for x in s['scores']],s['deduction'],('SUM(E%d:H%d)-I%d'%(i,i,i),total(s)),ct['total'],s['reported_count'],(f'IF(L{i}="","",K{i}-L{i})',ct['total']-s['reported_count'] if s['reported_count'] is not None else ''),f"{s['id']}_full.pdf",data['rubric_source']])
        rows[1].append([s['id'],s['short_comment']['en'],s['short_comment']['zh'],s['full_comment']['en'],s['full_comment']['zh']])
        for j,t in enumerate(s['tasks'],1):rows[2].append([s['id'],j,t['instruction'],'未開始',None,None])
        for e in s['errors']:rows[3].append([s['id'],e['sentence_id'],e['category'],e['original'],e['correction'],e['reason']])
        rows[4].append([s['id'],*s['reflections'],None,None,None,None])
    rows[5]=[['已批人數',(f"COUNTA('成績總表'!A2:A{n+1})",n)],['平均總分',(f"AVERAGE('成績總表'!J2:J{n+1})",sum(total(s) for s in students)/n)]]
    # One indicator per student makes repeated errors count as one affected student.
    er=max(2,len(rows[3])+1)
    for cat in ['Sp','G','W','P']:
        affected=sum(any(e['category']==cat for e in s['errors']) for s in students)
        formula='+'.join(f"IF(COUNTIFS('錯誤紀錄'!A2:A{er},'成績總表'!A{i},'錯誤紀錄'!C2:C{er},\"{cat}\")>0,1,0)" for i in range(2,n+2))
        rows[5].append([cat+' 涉及學生數',(formula,affected)])
    with ZipFile(ROOT/'templates/classroom.xlsx') as src, ZipFile(path,'w',ZIP_DEFLATED) as dest:
        for item in src.infolist():
            raw=src.read(item.filename)
            match=re.fullmatch(r'xl/worksheets/sheet(\d+)\.xml',item.filename)
            if match:
                index=int(match.group(1))-1; tree=ET.fromstring(raw); sd=tree.find(f'{{{NS}}}sheetData')
                head=deepcopy(sd.find(f'{{{NS}}}row')); template=sd.findall(f'{{{NS}}}row')[1]
                if index==0:
                    for j,score in enumerate(students[0]['scores'],4):
                        cell=list(head)[j]
                        style=cell.attrib.get('s','0'); ref=cell.attrib['r']
                        cell.clear();cell.attrib.update({'r':ref,'s':style,'t':'inlineStr'})
                        inline=ET.SubElement(cell,f'{{{NS}}}is');ET.SubElement(inline,f'{{{NS}}}t').text=f"{score['label']} /{score['max']:g}"
                styles={re.sub(r'\d','',c.attrib['r']):c.attrib.get('s','0') for c in template}
                sd.clear();sd.append(head)
                for ri,values in enumerate(rows[index],2):
                    row=ET.SubElement(sd,f'{{{NS}}}row',{'r':str(ri),'ht':str(115 if index in [1,2,3,4] else 40),'customHeight':'1'})
                    for ci,val in enumerate(values,1):
                        cell=ET.SubElement(row,f'{{{NS}}}c',{'r':column(ci)+str(ri),'s':styles.get(column(ci),'0')})
                        if val is None:continue
                        if isinstance(val,tuple):
                            ET.SubElement(cell,f'{{{NS}}}f').text=val[0]
                            if val[1]=='':cell.set('t','str')
                            ET.SubElement(cell,f'{{{NS}}}v').text=str(val[1])
                        elif isinstance(val,(float,int)):ET.SubElement(cell,f'{{{NS}}}v').text=str(val)
                        else:
                            cell.set('t','inlineStr');inline=ET.SubElement(cell,f'{{{NS}}}is');ET.SubElement(inline,f'{{{NS}}}t').text=str(val)
                width=len(head);end=max(2,len(rows[index])+1)
                dim=tree.find(f'{{{NS}}}dimension')
                if dim is not None:dim.set('ref',f'A1:{column(width)}{end}')
                af=tree.find(f'{{{NS}}}autoFilter')
                if af is not None:af.set('ref',f'A1:{column(width)}{end}')
                raw=ET.tostring(tree,encoding='utf-8',xml_declaration=True)
            elif item.filename=='xl/workbook.xml':
                tree=ET.fromstring(raw); calc=tree.find(f'{{{NS}}}calcPr')
                if calc is None:calc=ET.SubElement(tree,f'{{{NS}}}calcPr')
                calc.attrib.update({'calcMode':'auto','fullCalcOnLoad':'1'})
                raw=ET.tostring(tree,encoding='utf-8',xml_declaration=True)
            dest.writestr(item,raw)


def build(source,output,font,bold,hand):
    source,output=Path(source).resolve(),Path(output).resolve()
    if output.exists():raise FileExistsError('Choose a new output directory; originals are preserved')
    data=json.loads(source.read_text(encoding='utf-8-sig'));validate(data,source.parent)
    data['students'].sort(key=lambda s:(s['class'],s['seat']))
    register_fonts(font,bold,hand)
    output.parent.mkdir(parents=True,exist_ok=True)
    with tempfile.TemporaryDirectory(dir=output.parent) as temp:
        work=Path(temp); merged=PdfWriter(); audit=[]
        for s in data['students']:
            a,b=work/'front.pdf',work/'detail.pdf'
            front(a,data,s,source.parent);detail(b,data,s)
            full=PdfWriter();full.append(a);full.append(b)
            full.write(work/(s['id']+'_full.pdf'))
            read=PdfReader(a)
            if len(read.pages)!=2:raise ValueError('Print section must be exactly two pages')
            for page in read.pages:merged.add_page(page)
            audit.append({'id':s['id'],'score':total(s),'word_count':counts(s),'pages':len(full.pages)})
        merged.write(work/'class_print.pdf');workbook(data,work/'classroom.xlsx')
        (work/'audit.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2),encoding='utf-8')
        output.mkdir()
        for file in work.iterdir():
            if file.name not in ['front.pdf','detail.pdf']:shutil.copy2(file,output/file.name)
    return audit


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('input');parser.add_argument('--out',required=True)
    parser.add_argument('--font',required=True,help='CJK regular TTF/TTC')
    parser.add_argument('--bold',required=True,help='CJK bold TTF/TTC')
    parser.add_argument('--hand',required=True,help='Legible handwriting-style TTF')
    args=parser.parse_args()
    print(json.dumps(build(args.input,args.out,args.font,args.bold,args.hand),ensure_ascii=False,indent=2))
