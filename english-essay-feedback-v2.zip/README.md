# 高中英文作文精批與修訂 v2

跨 agent 批改規則 + 固定 PDF / Excel 輸出模板。Skill 呼叫名稱維持 `english-essay-feedback`。

## 分工

Agent 負責辨識、評分、批改與填寫 JSON；模板負責驗證資料、字數核算、排版及輸出。模板不自動評分、不替學生作答，也不保證不同模型評分完全相同。教師仍需覆核。

任何能讀取檔案、填寫 JSON 並執行 Python 的 agent 都可使用此流程。沒有程式執行能力的聊天工具可以填 JSON，但需交由其他執行環境製作成品。`agents/openai.yaml` 只是 OpenAI 顯示設定，不是渲染器依賴。

## 執行

1. 安裝 Python 3.10 以上與 `python -m pip install -r requirements.txt`。
2. 依 `templates/feedback.schema.json` 填寫資料；`examples/demo.json` 是完全虛構的可執行範例。
3. 提供合法可用的中文字型一般／粗體與英文手寫字型。字型不隨套件重散布。TTF 或受支援的 TTC 均可；不同機器使用相同字型可提高版面一致性。
4. 在套件目錄執行：

```text
python scripts/render_feedback.py examples/demo.json --out output/demo-v2 --font /path/to/cjk-regular.ttf --bold /path/to/cjk-bold.ttf --hand /path/to/handwriting.ttf
```

Windows 字型參數可使用 `C:/Windows/Fonts/msjh.ttc`、`C:/Windows/Fonts/msjhbd.ttc`、`C:/Windows/Fonts/comicbd.ttf`。macOS / Linux 請提供實際安裝的字型檔路徑。無效字型會停止，不能以缺字方框交付。

輸出目錄必須尚未存在，避免覆寫原稿或舊成品。輸出包括每生 `id_full.pdf`、`class_print.pdf`、`classroom.xlsx`、`audit.json`。每生前兩頁固定，後續詳解自動分頁。

## 原稿與紅筆位置

`scan` 為相對於 JSON 的原稿圖片路徑。未提供時，第一頁明確顯示逐字稿，不能假裝已在手寫原稿上批改。多頁原稿需先整理成可讀的版面；若第一頁容不下，先與教師調整列印安排，不縮小字硬塞。

`annotations` 各筆為 `x,y,width,label,text`。座標從原稿圖片左上角起算，0–1 為相對比例，y 是批改文字框的上緣。將註記放在原字上方留白；工具檢查註記彼此重疊與越界，仍須目視確認沒有蓋住原字。修訂字級固定 12pt。

## 固定版型與品質

第1頁原稿／紅筆、分項橫表與英中短評。第2頁評分依據表、英中完整評語、三項任務（每題至少3行）、三題反思。第3頁起逐句精修，最後兩版英中範文。正文 11–12pt，不自動縮字；文字超出前兩頁容量即報錯，agent 應刪減重複敘述或與教師調整安排。

Excel 使用隨附固定範本；執行時以 Python 標準 XML/ZIP API 填入資料，不依賴 Codex 私有函式庫。包含成績、評語、修訂、錯誤、反思、摘要六表；總分、字數差異及摘要有公式與初始快取，Excel 開啟後重算。修改 Excel 不會反向更新 PDF，請修改 JSON 後產生新版本以保持一致。

目前支援同一量尺四項分數的批次。非四項規準應先調整 schema 與模板，不硬套。範本成績欄名預設學測四項，渲染時會依輸入項目更新。姓名不確定填「待核對」；疑義列於 `uncertainties`。

這是固定產出管線，不包含其他 agent 的帳號設定、GitHub 授權或自動同步。驗證一個 agent 可執行，不代表已在所有 agent / 作業系統實測。範例完全虛構；上傳 GitHub 不包含教師字型或學生資料。

## 2026-10-14 驗證紀錄

已在 Windows 執行短文、840字120句長文、多生排序與每人兩頁合併、缺中譯／分數越界／重複身份／逐字稿不一致等拒絕測試，以及合成原稿影像紅筆註記測試。Excel 六表已渲染檢視；試算表引擎修改內容分數3→4後，總分11→12，並確認同生兩筆 G 錯誤只計一位學生。未在 macOS、Linux 或其他 agent 實測，也未驗證原生 Excel 的全部操作。

`scripts/test_renderer.py` 內的整合測試使用 Windows 系統字型；在其他作業系統執行測試前需替換測試字型路徑。渲染器本身以命令列字型參數運作。
