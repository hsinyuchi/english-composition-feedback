"""Behavioral tests using synthetic records only."""
import copy
import json
from pathlib import Path
import tempfile
import unittest
from zipfile import ZipFile
import xml.etree.ElementTree as ET
from jsonschema import ValidationError
from pypdf import PdfReader
from PIL import Image, ImageDraw, ImageFont
from render_feedback import ROOT, NS, validate, build


class RendererTests(unittest.TestCase):
    def setUp(self):
        self.data=json.loads((ROOT/'examples/demo.json').read_text(encoding='utf-8'))

    def test_invalid_records(self):
        for mutation in ['translation','score','duplicate','transcription','annotation','six_rewrites','reserved_filename']:
            d=copy.deepcopy(self.data);s=d['students'][0]
            if mutation=='translation':del s['models']['basic'][0]['zh']
            elif mutation=='score':s['scores'][0]['value']=6
            elif mutation=='duplicate':d['students'].append(copy.deepcopy(s))
            elif mutation=='transcription':s['sentences'][0]['original']='Different.'
            elif mutation=='six_rewrites':s['optional_rewrites']=[s['optional_rewrites'][0]]*6
            elif mutation=='reserved_filename':s['pdf_filename']='class_print.pdf'
            else:s['annotations']=[{'x':.9,'y':.1,'width':.5,'label':'G','text':'has'}]
            with self.subTest(mutation=mutation),self.assertRaises((ValidationError,ValueError)):
                validate(d,ROOT/'examples')

    def test_long_batch_and_excel(self):
        d=copy.deepcopy(self.data);short=d['students'][0];long=copy.deepcopy(short)
        long['id']='demo-long';long['seat']=2;long['reported_count']=None
        long['sentences']=[{'id':i,'original':f'I visit the park on day {i}.','basic':f'I visit the park on day {i}.','notes':['原句可保留。'],'advanced':f'I enjoy visiting the park on day {i}.'} for i in range(1,121)]
        long['paragraphs']=[' '.join(x['original'] for x in long['sentences'][:35]),' '.join(x['original'] for x in long['sentences'][35:])]
        long['errors']=[]
        d['students']=[long,short]
        short['optional_rewrites']=[copy.deepcopy(short['optional_rewrites'][0]) for _ in range(5)]
        with tempfile.TemporaryDirectory() as temp:
            root=Path(temp);source=root/'batch.json';source.write_text(json.dumps(d),encoding='utf-8')
            output=root/'result'
            audit=build(source,output,'C:/Windows/Fonts/msjh.ttc','C:/Windows/Fonts/msjhbd.ttc','C:/Windows/Fonts/comicbd.ttf')
            self.assertEqual([a['id'] for a in audit],['demo-01','demo-long'])
            self.assertEqual(len(PdfReader(output/'class_print.pdf').pages),4)
            first=PdfReader(output/'demo-01_full.pdf').pages[0].extract_text()
            self.assertNotIn(short['short_comment']['en'],first)
            self.assertIn('完整英中評語見第2頁',first)
            self.assertNotIn('原寫法可保留',first)
            self.assertNotIn('也可以這樣寫',first)
            detail_text='\n'.join(p.extract_text() for p in PdfReader(output/'demo-01_full.pdf').pages[2:])
            self.assertEqual(detail_text.count('可選潤飾｜原寫法可保留'),5)
            second=PdfReader(output/'demo-01_full.pdf').pages[1].extract_text()
            for label in ['本篇個別化修訂任務','任務1','任務2','任務3','學習歷程反思','回溯自評','修訂日期','教師回饋']:
                self.assertIn(label,second)
            for task in short['tasks']:
                self.assertIn(task['instruction'],second.replace('\n',''))
            self.assertNotIn('另附',second);self.assertNotIn('不是學生',second)
            self.assertGreater(audit[1]['pages'],audit[0]['pages'])
            text='\n'.join(p.extract_text() for p in PdfReader(output/'demo-long_full.pdf').pages)
            self.assertIn('原稿節錄',text);self.assertIn('day 120',text);self.assertIn('SENTENCE 120',text)
            with ZipFile(output/'classroom.xlsx') as z:
                main=ET.fromstring(z.read('xl/worksheets/sheet1.xml'))
                summary=ET.fromstring(z.read('xl/worksheets/sheet6.xml'))
                cells={c.attrib['r']:c for c in main.iter(f'{{{NS}}}c')}
                self.assertEqual(cells['J2'].find(f'{{{NS}}}v').text,'11')
                self.assertEqual(cells['M3'].find(f'{{{NS}}}v').text,None)
                reflection=ET.fromstring(z.read('xl/worksheets/sheet5.xml'))
                rc={c.attrib['r']:c for c in reflection.iter(f'{{{NS}}}c')}
                self.assertEqual(''.join(rc['D2'].itertext()),'')
                self.assertEqual(''.join(rc['E2'].itertext()),'')
                sc={c.attrib['r']:c for c in summary.iter(f'{{{NS}}}c')}
                self.assertEqual(sc['B5'].find(f'{{{NS}}}v').text,'1')
            with self.assertRaises(FileExistsError):
                build(source,output,'unused','unused','unused')

    def test_scan_annotations(self):
        d=copy.deepcopy(self.data)
        with tempfile.TemporaryDirectory() as temp:
            root=Path(temp)
            image=Image.new('RGB',(1100,800),'white');draw=ImageDraw.Draw(image)
            font=ImageFont.truetype('C:/Windows/Fonts/georgia.ttf',30)
            draw.text((60,180),'The park have many trees.',font=font,fill='black')
            draw.text((60,330),'I enjoy walk there.',font=font,fill='black')
            draw.text((60,480),'It is quiet, so I can relax after school.',font=font,fill='black')
            image.save(root/'scan.png')
            s=d['students'][0];s['scan']='scan.png'
            s['annotations']=[{'x':.23,'y':.17,'width':.22,'label':'G','text':'has','operation':'replace','target':[.23,.27,.06]}, {'x':.17,'y':.36,'width':.25,'label':'G','text':'walking','operation':'replace','target':[.17,.46,.07]}]
            s['annotations'].append({'x':0,'y':0,'width':.1,'label':'G','text':'del.','operation':'delete','target':[.1,.65,.05]})
            source=root/'scan.json';source.write_text(json.dumps(d),encoding='utf-8')
            build(source,root/'result','C:/Windows/Fonts/msjh.ttc','C:/Windows/Fonts/msjhbd.ttc','C:/Windows/Fonts/comicbd.ttf')
            page=PdfReader(root/'result/demo-01_full.pdf').pages[0]
            self.assertIn('walking',page.extract_text());self.assertGreater(len(page.images),0)
            self.assertNotIn('del.',page.extract_text())

    def test_three_reflections_compatibility(self):
        d=copy.deepcopy(self.data)
        d['students'][0]['reflections'].append('下一篇先檢查什麼？')
        with tempfile.TemporaryDirectory() as temp:
            root=Path(temp);source=root/'three.json'
            source.write_text(json.dumps(d),encoding='utf-8')
            build(source,root/'result','C:/Windows/Fonts/msjh.ttc','C:/Windows/Fonts/msjhbd.ttc','C:/Windows/Fonts/comicbd.ttf')
            second=PdfReader(root/'result/demo-01_full.pdf').pages[1].extract_text()
            self.assertIn('下一篇先檢查什麼',second)
        for n in [1,4]:
            bad=copy.deepcopy(d);bad['students'][0]['reflections']=['測試']*n
            with self.assertRaises(ValidationError):validate(bad,ROOT/'examples')


if __name__=='__main__':unittest.main()
